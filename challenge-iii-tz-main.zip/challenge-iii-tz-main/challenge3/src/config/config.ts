//API_URL
export const API_URL = "https://deskbooking.dev.webundsoehne.com";
